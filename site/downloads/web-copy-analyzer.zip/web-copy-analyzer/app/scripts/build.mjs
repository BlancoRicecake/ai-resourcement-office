#!/usr/bin/env node
/**
 * Bundles the CLI (app/cli.ts) and MCP server (app/mcp/bin.ts) into
 * single-file, zero-external-dependency JS (app/dist/cli.js, app/dist/mcp.js)
 * so the downloaded bundle runs with `node dist/cli.js` / `node dist/mcp.js`
 * without `npm install` — the repo's "unzip and run" bundle model. esbuild
 * was previously used for this service's (now-dropped) web showroom build;
 * it is repurposed here for the mcp+cli bundling only.
 *
 * The MCP server's TypeScript source lives at app/mcp/ (not worker/mcp/)
 * because Node/TS module resolution needs `@modelcontextprotocol/sdk` to be
 * found by walking up from the importing file's directory, and `npm install`
 * (per this bundle's build docs) runs inside app/, producing app/node_modules
 * — a directory outside app/ would never resolve it. worker/mcp/ carries only
 * documentation (README.md) pointing at this build output; dist/ itself is
 * release-asset-only per the repo's .gitignore (`dist/`), not committed.
 */
import * as esbuild from "esbuild";
import { mkdirSync, copyFileSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const APP_DIR = path.dirname(path.dirname(fileURLToPath(import.meta.url))); // app/
const ROOT = path.dirname(APP_DIR); // bundle root
const OUT_DIR = path.join(APP_DIR, "dist");

mkdirSync(OUT_DIR, { recursive: true });

const targets = [
  { name: "cli", entry: path.join(APP_DIR, "cli.ts"), out: path.join(OUT_DIR, "cli.js") },
  { name: "mcp", entry: path.join(APP_DIR, "mcp", "bin.ts"), out: path.join(OUT_DIR, "mcp.js") },
];

for (const { entry, out } of targets) {
  await esbuild.build({
    entryPoints: [entry],
    bundle: true,
    platform: "node",
    format: "esm",
    target: "node18",
    outfile: out,
    logLevel: "info",
  });
}

// worker/agent.md must live next to the bundled dist/mcp.js so
// defaultAgentsMdPath() (app/mcp/server.ts) finds it at runtime without
// depending on the source-tree layout.
copyFileSync(path.join(ROOT, "worker", "agent.md"), path.join(OUT_DIR, "agent.md"));

for (const { name, out } of targets) {
  const size = readFileSync(out, "utf8").length;
  if (size < 500) throw new Error(`build smoke check failed: ${name} bundle (${out}) suspiciously small (${size} bytes)`);
}

console.log(`bundled -> ${path.relative(ROOT, OUT_DIR)}/ (cli.js, mcp.js, agent.md)`);
